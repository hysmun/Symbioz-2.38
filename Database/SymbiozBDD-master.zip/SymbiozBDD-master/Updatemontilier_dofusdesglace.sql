UPDATE items SET Effects = '153#100#0#0|118#140#0#0|' WHERE id = 14848;
UPDATE items SET Effects = '153#100#0#0|126#140#0#0|' WHERE id = 14854;
UPDATE items SET Effects = '418#25#0#0|' WHERE id = 13603;
UPDATE items SET Effects = '153#100#0#0|118#140#0#0|138#50#0#0|210#5#0#0|211#5#0#0|212#5#0#0|213#5#0#0|214#5#0#0|' WHERE id = 13182;
UPDATE items SET Effects = '115#5#0#0|128#1#0#0|' WHERE id = 15243;
UPDATE items SET Effects = '158#1000#0#0|' WHERE id = 13465;
UPDATE items SET Effects = '176#80#0#0|' WHERE id = 12963;
UPDATE items SET Effects = '153#100#0#0|111#1#0#0|' WHERE id = 14827;
UPDATE items SET Effects = '153#100#0#0|119#140#0#0|' WHERE id = 14833;
UPDATE items SET Effects = '1179#0#0#121|111#1#0#0|125#100#0#0|112#10#0#0|' WHERE id = 15861;
UPDATE items SET Effects = '153#100#0#0|123#140#0#0|' WHERE id = 14838;
UPDATE items SET Effects = '138#50#0#0|' WHERE id = 12541;
UPDATE items SET Effects = '428#20#0#0|422#20#0#0|424#20#0#0|426#20#0#0|430#20#0#0|' WHERE id = 7043;

