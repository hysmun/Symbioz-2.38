--Enclos public
UPDATE interactives SET ElementId = '486788' WHERE mapId = 150328;
UPDATE interactives SET ElementId = '486787' WHERE mapId = 150840;
UPDATE interactives SET ElementId = '486791' WHERE mapId = 150841;
UPDATE interactives SET ElementId = '486785' WHERE mapId = 150329;
UPDATE interactives SET ElementId = '486784' WHERE mapId = 150330;
UPDATE interactives SET ElementId = '486786' WHERE mapId = 149817;
UPDATE interactives SET ElementId = '486790' WHERE mapId = 146470;
UPDATE interactives SET ElementId = '486783' WHERE mapId = 146469;
UPDATE interactives SET ElementId = '486789' WHERE mapId = 146982;

-- porte zaap astrub 
Insert into interactives VALUES (974,84674563,114,465429,0,'Teleport',83886080,270);
Insert into interactives VALUES (975,83886080,114,465430,0,'Teleport',84674563,242);
Insert into interactives VALUES (976,83886080,114,465428,0,'Teleport',83888130,386);
Insert into interactives VALUES (977,83888130,114,464298,0,'Teleport',83888132,354);
Insert into interactives VALUES (978,83888132,114,464299,0,'Teleport',83888130,382);



-- porte arene
Insert into interactives VALUES (969,147769,114,415073,0,'Teleport',2884110,478);
Insert into interactives VALUES (970,2884110,114,462055,0,'Teleport',74186754,415);
Insert into interactives VALUES (971,2884110,114,462052,0,'Teleport',4980738,328);
Insert into interactives VALUES (972,2884110,114,462053,0,'Teleport',4981250,511);
Insert into interactives VALUES (973,2884110,114,462054,0,'Teleport',4981762,328);

-- porte arene brakmar

Insert into interactives VALUES (979,144934,114,419011,0,'Teleport',8912922,506);
Insert into interactives VALUES (980,8912922.,114,462061,0,'Teleport',74187778,415);
Insert into interactives VALUES (981,8912922.,114,455083,0,'Teleport',11796482,342);
Insert into interactives VALUES (982,8912922.,114,462059,0,'Teleport',11796994,511);
Insert into interactives VALUES (983,8912922.,114,462060,0,'Teleport',11797506,328);

-- Milice brak

Insert into interactives VALUES (984,144420,114,415729,0,'Teleport',13631488,477);
Insert into interactives VALUES (985,144420,114,433918,0,'Teleport',13631488,520);

Insert into interactives VALUES (986,13631488,114,455939,0,'Teleport',13632512,366);
Insert into interactives VALUES (987,13631488,114,455940,0,'Teleport',13632512,379);

Insert into interactives VALUES (988,13632512,114,455365,0,'Teleport',13631488,458);
Insert into interactives VALUES (989,13632512,114,455364,0,'Teleport',13631488,444);

Insert into interactives VALUES (990,13632512,114,455931,0,'Teleport',13633536,136);
Insert into interactives VALUES (991,13632512,114,455932,0,'Teleport',13633536,150);

Insert into interactives VALUES (992,13633536,114,459377,0,'Teleport',69994496,394);

Insert into interactives VALUES (993,69994496,114,459027,0,'Teleport',13633536,270);
Insert into interactives VALUES (994,69994496,114,459029,0,'Teleport',13633536,270);

Insert into interactives VALUES (995,13631488,114,455374,0,'Teleport',13634560,325);
Insert into interactives VALUES (996,13631488,114,455373,0,'Teleport',13634560,311);

Insert into interactives VALUES (997,13634560,114,455935,0,'Teleport',13631488,76);
Insert into interactives VALUES (998,13634560,114,455936,0,'Teleport',13631488,62);

Insert into interactives VALUES (999,13634560,114,455375,0,'Teleport',13631490,245);
Insert into interactives VALUES (1000,13634560,114,455376,0,'Teleport',13631490,245);

Insert into interactives VALUES (1001,13631490,114,455937,0,'Teleport',13634560,230);
Insert into interactives VALUES (1002,13631490,114,455938,0,'Teleport',13634560,216);

Insert into interactives VALUES (1003,13633538,114,455934,0,'Teleport',13631490,332);
Insert into interactives VALUES (1004,13633538,114,455933,0,'Teleport',13631490,332);

Insert into interactives VALUES (1005,13633536,114,455370,0,'Teleport',13632512,319);
Insert into interactives VALUES (1006,13633536,114,455369,0,'Teleport',13632512,319);

Insert into interactives VALUES (1007,13631490,114,455380,0,'Teleport',13633538,276);
Insert into interactives VALUES (1008,13631490,114,455381,0,'Teleport',13633538,276);

-- Milice bonta

Insert into interactives VALUES (1009,148280,114,415740,0,'Teleport',5506048,506);

-- Accès Kolizéum

Insert into interactives VALUES (1010,138013,114,463608,0,'Teleport',81788928,479);
Insert into interactives VALUES (1011,81788928,114,463607,0,'Teleport',81788930,429);
Insert into interactives VALUES (1012,81788928,114,463606,0,'Teleport',81789952,437);

-- Accès Malles aux trésors
Insert into interactives VALUES (1013,144164,114,484926,0,'Teleport',128451073,494);
Insert into interactives VALUES (1014,128451073,114,484927,0,'Teleport',144164,356);

Insert into interactives VALUES (1015,128453121,114,484929,0,'Teleport',143652,357);
Insert into interactives VALUES (1016,143652,114,484928,0,'Teleport',128453121,499);


